(function($) {

	$(function() {
		var $win = $(window),
			$doc = $(document),
			$html = $(document.documentElement),
			isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
			if (document.location.search.indexOf('mobile') != -1) {isMobile = true};

		$('table').wrap('<div class="table-wrapper"></div>');

		$.datepicker.regional['ru'] = {
			closeText: 'Закрыть',
			prevText: '<Пред',
			nextText: 'След>',
			currentText: 'Сегодня',
			monthNames: ['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'],
			monthNamesTitle: ['Янв','Фев','Мар','Апр','Май','Июн','Июл','Авг','Сен','Окт','Ноя','Дек'],
			dayNames: ['воскресенье','понедельник','вторник','среда','четверг','пятница','суббота'],
			dayNamesShort: ['вск','пнд','втр','срд','чтв','птн','сбт'],
			dayNamesMin: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
			weekHeader: 'Нед',
			dateFormat: 'dd.mm.yy',
			firstDay: 1,
			isRTL: false,
			showMonthAfterYear: false,
			yearSuffix: ''};
		$.datepicker.setDefaults($.datepicker.regional['ru']);

		var $selects = $('.my_form select');
								
		$selects.easyDropDown({
			wrapperClass: 'dropdown'
		});

		if ($('.reviews .jblock').length>1){
		    $('.reviews').owlCarousel({
		        loop: true,
		        nav: true,
		        dots: false,
		        autoplay:false,
		        autoHeight : false,
		        responsive : {
				    0 : {
				        items: 1,
				        margin:0
				    },
				    980 : {
				        items: 2,
				        margin: 45
				    }
				}
		    });
		};

		s3From.initForms(".form_wrapper", function() {

			var $selects = $('.my_form select');
								
			$selects.easyDropDown({
				wrapperClass: 'dropdown'
			});

			$( ".datepickerFrom" ).datepicker({
		        minDate:0,
		        changeMonth: false,
		        numberOfMonths: 1,
		        onClose: function( selectedDate ) {
		            initTo.datepicker( 'option', 'minDate', selectedDate );
		            setTotalValue();
		        }
		    });

			var initFrom = $('.firstInput' );
		    var initTo = $('.secondInput' );
		    var initTotal = $('.firstAndSecondVal' );
		    
		    function setTotalValue () {
		        initTotal.val('от ' + initFrom.val() + ' до ' + initTo.val());
		    };
		    initFrom.datepicker({
		        minDate:0,
		        changeMonth: false,
		        numberOfMonths: 1,
		        onClose: function( selectedDate ) {
		            initTo.datepicker( 'option', 'minDate', selectedDate );
		            setTotalValue();
		        }
		    });
		    initTo.datepicker({
		        defaultDate: '+1w',
		        minDate:0,
		        changeMonth: false,
		        numberOfMonths: 1,
		        onClose: function( selectedDate ) {
		            initFrom.datepicker( 'option', 'maxDate', selectedDate );
		            setTotalValue();
		        }
		    });

		});

		$( ".datepickerFrom" ).datepicker({
	        minDate:0,
	        changeMonth: false,
	        numberOfMonths: 1,
	        onClose: function( selectedDate ) {
	            initTo.datepicker( 'option', 'minDate', selectedDate );
	            setTotalValue();
	        }
	    });

		var initFrom = $('.firstInput' );
	    var initTo = $('.secondInput' );
	    var initTotal = $('.firstAndSecondVal' );
	    
	    function setTotalValue () {
	        initTotal.val('от ' + initFrom.val() + ' до ' + initTo.val());
	    };
	    initFrom.datepicker({
	        minDate:0,
	        changeMonth: false,
	        numberOfMonths: 1,
	        onClose: function( selectedDate ) {
	            initTo.datepicker( 'option', 'minDate', selectedDate );
	            setTotalValue();
	        }
	    });
	    initTo.datepicker({
	        defaultDate: '+1w',
	        minDate:0,
	        changeMonth: false,
	        numberOfMonths: 1,
	        onClose: function( selectedDate ) {
	            initFrom.datepicker( 'option', 'maxDate', selectedDate );
	            setTotalValue();
	        }
	    });
	    
		$('.jblock_wrapper1 .title').equalHeightResponsive();
		$('.jblock_wrapper1 .text').equalHeightResponsive();

		if (isMobile) {
			$('.link_top').on('touchstart click', function(){
				$('html, body').animate({
					scrollTop: 0
				}, 800);
				return false;
			});
		} else {
			$('.link_top').on('click', function(){
				$('html, body').animate({
					scrollTop: 0
				}, 800);
				return false;
			});
		};

		$('.menu_open').on('click', function(menu){
			$('.menu-top-wrap').addClass('opened');
			$('html, body').addClass('overflowHidden');
		});

		$('.menu_close').on('click', function(menu){
			$('.menu-top-wrap').removeClass('opened');
			$('html, body').removeClass('overflowHidden');
		});

		$(document).on('click touchstart', function(menu){
		    if( $(menu.target).closest('.menu_open').length || $(menu.target).closest('.menu-top-wrap').length) 
		      return;
		    $('.menu-top-wrap').removeClass('opened');
			$('html, body').removeClass('overflowHidden');
		});

		$('.menu-top li a').append('<span class="my_span"></span>');

		resizeController([0, 979], function() {
			$(".menu-top ul").each(function(index, el) {
				$(el).closest("li").find("> a > .my_span").on("click", function(event) {
					$(this).closest("li").toggleClass("opened_level");
					return false;
				});
			});
		});

		resizeController([980, Infinity], function() {

			$('.menu-top li a').on('click', function() {
	            if ($(this).hasClass('s3-menu-allin-open')) {
	                document.location.href = $(this).attr('href');
	            };
	        });

	        $(document).on('click touchstart', function(my_event){
	            if( $(my_event.target).closest('.menu-top-wrap').length || $(my_event.target).closest('.menu-top-wrap .menu-top ul').length) 
	              return;
	            $('.menu-top-wrap .menu-top li a').removeClass('s3-menu-allin-open');
			    $('.menu-top-wrap .menu-top ul').removeAttr('style');
	        });

			if (isMobile) {
				$(".menu-top").s3MenuAllIn({
					type: 'dropdown',
			        showTime: 150,
			        hideTime: 150,
			        showFn: $.fn.fadeIn,
			        hideFn: $.fn.fadeOut
				});
			} else {
				$('.menu-top ul').parent().each(function() {
					var o = $(this);
					var s = o.find('>ul');
					var l = o.parents('ul').length;
					var k = false;
					o.hover(
						function() {
							o.find('>a').attr('class','active');
							for (i=$('.menu-top ul').length; i>=0; i--){
								o.parent().find('>li').not(o).find('ul').eq(i).hide();
							}
							k = true;
							var p = o.position();
							var ts, ls;
							if (l == 1) {
								ts =  p.top + o.height();
								ls = p.left;
							} else {
								ts = p.top;
								ls = p.left + o.width();
							}
							s.css({
								top: ts,
								left: ls
							}).fadeIn(150);
						},
						function() {
							o.find('>a').attr('class','normal');
							k = false;
							window.setTimeout(function() {
								if (!k) s.fadeOut(150); 						   
							}, 150);
						}
					);
				});
			};

		});
		
	});
	
	// YandexMap
	(function() {

		function coords(str) {
			return str.split(',');
		}

		function init(options) {
			options.center = coords(options.center);
	
			$.each(options.data, function(key, item) {
				item.coords = coords(item.coords);
			});
	
			if (options.type == 1) {
	
				google.maps.event.addDomListener(window, 'load', function() {
					
					var map = new google.maps.Map(document.getElementById(options.id), {
						zoom: 15,
						scrollwheel: false,
						center: new google.maps.LatLng(options.center[0], options.center[1])
					});
	
					$.each(options.data, function(key, item) {

						var marker = new google.maps.Marker({
							position: new google.maps.LatLng(item.coords[0], item.coords[1]),
							map: map,
							title: item.name
						});
	
						var infowindow = new google.maps.InfoWindow({
							content: '<div class="baloon-content">' +
										'<h3 style="margin: 0; padding-bottom: 3px;">' + item.name + '</h3>' +
										item.desc +
									 '</div>'
						});
	
						google.maps.event.addListener(marker, 'click', function() {
							infowindow.open(map, marker);
						});
	
					});
				});
	
			} else {
	
				ymaps.ready(function() {
	
					var map = new ymaps.Map(options.id, {
						center: options.center,
						zoom: options.zoom,
						behaviors: ['drag', 'rightMouseButtonMagnifier'],
					});
	
					map.controls.add(
						new ymaps.control.ZoomControl()
					);
	
					var MyBalloonContentLayoutClass = ymaps.templateLayoutFactory.createClass(
						'<div class="baloon-content" style="padding: 0 10px;">' +
							'<h3 style="margin: 0;">$[properties.name]</h3>' +
							'$[properties.desc]' +
						'</div>'
					);
	
					var myCollection = new ymaps.GeoObjectCollection();
	
					$.each(options.data, function(key, item) {
						myCollection.add(new ymaps.Placemark(
							item.coords,
							item, 
							{balloonContentLayout: MyBalloonContentLayoutClass}
						));
					});
	
					map.geoObjects.add(myCollection);
	
				});
			}
		}
	
		window.mjsMap = init;
	})();
	// /YandexMap

})(jQuery);